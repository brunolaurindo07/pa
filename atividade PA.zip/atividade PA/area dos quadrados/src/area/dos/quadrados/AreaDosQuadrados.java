
package area.dos.quadrados;

import java.util.Scanner;



public class AreaDosQuadrados {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double lado,resposta;
        //
        Scanner entrada= new Scanner (System.in);
                
       System.out.println("digite a medida de um dos lados do seu quadrado: ");
       lado= entrada.nextDouble();
               
               resposta= lado*lado;
        
         System.out.println("a área do seu quadrado é: "+resposta);
        
        
    }
    
}
