/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package juros;

import java.util.Scanner;

/**
 *
 * @author marcos tavarres
 */
public class Juros {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double emprest,taxa,r;
        int tempo;
        
        Scanner entrada = new Scanner(System.in);
        
        System.out.println("Quanto deseja emprestado ?  ");
        emprest= entrada.nextDouble();
        
        System.out.println("Em quntos meses pretende pagar ?  ");
        tempo= entrada.nextInt();
        
        taxa=0.02;
        
        Math.pow(emprest,emprest);
        
        r= emprest*(Math.pow((1+taxa ),tempo));
        
          System.out.println("ao final de "+tempo+" meses , você pagará : R$ "+r+" reais");
        
    }
    
}
