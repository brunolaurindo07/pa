/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoretangulo;

import java.util.Scanner;

/**
 *
 *@author bruno
 */
public class Projetoretangulo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    double area,perimetro,base,altura;
    
    Scanner entrada = new Scanner (System.in);
        
        System.out.println("digite a base do retangulo :  ");
        base =entrada.nextDouble();
        
        System.out.println("digite a altura do retangulo :  ");
        altura =entrada.nextDouble();
        
        //processamento
        area= base*altura;
        perimetro =((base*2)+(altura*2));
        
         System.out.println("a area do retangulo é :  "+area);
        
         System.out.println("o perimetro do retangulo é :  "+perimetro);
    }
    
}
