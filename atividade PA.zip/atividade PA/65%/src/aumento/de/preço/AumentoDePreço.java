/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aumento.de.preço;

import java.util.Scanner;

/**
 *
 * @author marcos tavarres
 */
public class AumentoDePreço {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * bruno
 */


   
        double preco, resultado;
        String nome;
        // entrada
        Scanner entrada= new Scanner (System.in);
        
        System.out.println("digite o nome do seu produto:    ");
        nome = entrada.next();
        
       
          System.out.println("digite o preço do seu produto :   ");
      preco= entrada.nextDouble();
      
      //processamento
      resultado= (preco*1.65);
      
      System.out.println("o preço do seu produto "   +nome+    "  será de " +resultado + " após o aumento de 65%");
        
    }
    
    }
    
    

